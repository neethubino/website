<?php include('header.php')?>
<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script>
<script type='text/javascript'>
function displayForm(c) {
    if (c.value == "offgrid") {    
        jQuery('#paypalformContainer').toggle('show');
        jQuery('#ccformContainer').hide();
    }
        if (c.value == "ongrid") {
         jQuery('#ccformContainer').toggle('show');
         jQuery('#paypalformContainer').hide();
    }
};
</script>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page signup-page">
				<?php 
				        $msg=$this->session->flashdata('msg');
				        if($msg)
				        {
				        ?>
				          
				        <div class="alert alert-success" >
				        <?php
				          echo $msg;
				        ?>
				        </div>
				        <?php 
				        }
				        ?>
				<!-- <h2 class="title1">REGISTER CUSTOMER HERE</h2> -->
				<div class="sign-up-row widget-shadow"  style="width: 850px;margin-left: -150px;" >
					<h5>Category Details</h5>
					<label>&nbsp;&nbsp;Category</label><label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rate</label>
					<?php 
						foreach ($details as $key => $value) {
					
						?>
					<form class="form-inline"> 

						
						<div class="form-group"> <label for="exampleInputName2"></label> <input type="text" class="form-control"   style="height: 40px;width: 295px" value=" <?php echo $value->check1;?>"> </div> <div class="form-group"> <label for="exampleInputEmail2"></label> <input type="text" class="form-control" style="height: 40px;width: 290px" value="<?php echo $value->rate1;?>"> </div> 

 						<div class="form-group"> <label for="exampleInputName2"></label> <input type="text" class="form-control"   style="height: 40px;width: 295px" value=" <?php echo $value->check2;?>"> </div> <div class="form-group"> <label for="exampleInputEmail2"></label> <input type="text" class="form-control" style="height: 40px;width: 290px" value="<?php echo $value->rate2;?>"> </div> 
 						
						<div class="form-group"> <label for="exampleInputName2"></label> <input type="text" class="form-control"   style="height: 40px;width: 290px" value=" <?php echo $value->check3;?>"> </div> <div class="form-group"> <label for="exampleInputEmail2"></label> <input type="text" class="form-control" style="height: 40px;width: 290px" value="<?php echo $value->rate3;?>"> </div> 
 						
						<div class="form-group"> <label for="exampleInputName2"></label> <input type="text" class="form-control"   style="height: 40px;width: 290px" value=" <?php echo $value->check4;?>"> </div> <div class="form-group"> <label for="exampleInputEmail2"></label> <input type="text" class="form-control" style="height: 40px;width: 290px" value="<?php echo $value->rate4;?>"> </div> 
 


					
					<div class="sub_home" style="margin-right: -160px;">
							<input type="submit" value="Update">
						<div class="clearfix"> </div>
					</div>
					
				</form>
			<?php } ?>
				</div>
			</div>
		</div>
	<?php include('footer.php');?>