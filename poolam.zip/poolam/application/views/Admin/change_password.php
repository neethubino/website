<?php include('header.php')?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page signup-page">
				<!-- <h2 class="title1">REGISTER CUSTOMER HERE</h2> -->
				<div class="sign-up-row widget-shadow"  style="width: 100%;">
					<h5>Change Password</h5>
				<form action="<?php echo base_url('Admin/change_pswd');?>" method="post">
					
								<input type="text" name="old_pass" placeholder="Old Password" required="">
						
					

								<input type="text" placeholder="New Password" required="" name="new_pass">


								<input type="text" placeholder="Confirm Password" required="" name="confirm_pass">

								<?php if($this->session->flashdata('msg')){  ?>

       							 <div >
            
           							 <strong></strong> <?php echo $this->session->flashdata('msg'); ?>
        						</div>
    
    							 <?php } else if($this->session->flashdata('msg1')){ ?>

        <div >
            <!-- <a href="#" class="close" data-dismiss="alert"></a> -->
             <?php echo $this->session->flashdata('msg1'); ?>
        </div>
        <?php } ?>
								

								
					
					<div class="sub_home">
							<input type="submit" value="Submit" name="change_pass">
						<div class="clearfix"> </div>
					</div>
					
				</form>
				</div>
			</div>
		</div>
		<?php include('footer.php');?>