<?php include('header.php');?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
				<div class="forms">
					
					
	
					<div class="row">
						<h3 class="title1">Add Hotel Details :</h3>
						<div class="form-three widget-shadow">
							<?php 
						foreach ($details as $key => $value) {
					
						?>
							<form class="form-horizontal" method="post" action="<?php echo base_url('Admin/updatehoteldetails/'.$value->hotel_id);?>" enctype="multipart/form-data" >
								<div class="form-group">
									<label for="focusedinput" class="col-sm-2 control-label">Hotel Name</label>
									<div class="col-sm-8">
										<input type="text" name="hotelname" class="form-control1" id="focusedinput"  value="<?php echo $value->hotel_name;?>">
									</div>
									<div class="col-sm-2">
										<!-- <p class="help-block">Your help text!</p> -->
									</div>
								</div>
								<div class="form-group">
									<label for="disabledinput" class="col-sm-2 control-label">Location</label>
									<div class="col-sm-8">
										<input type="text" name="location" class="form-control1" id="focusedinput" value="<?php echo $value->location; ?>">
									</div>
								</div>
								<div class="form-group">
									<label for="inputPassword" class="col-sm-2 control-label">Hotel Image</label>
									<div class="col-sm-8">
										<img  style="width: 200px; height: 150px;"  src="<?php echo base_url('upload/'.$value->hotel_image);?>">
										<input type="file" name="image" class="form-control1" id="inputPassword" placeholder="Password">
									</div>
								</div>
									
									<div class="form-group">
									<label for="inputPassword" class="col-sm-2 control-label">Pool Type</label>
									<div class="col-sm-8">
										<select class="form-control1" name="pool_name">
											<option > Pool Name   </option>
											<option value="type1" >pool type1</option>
											<option value="type2">pool type2</option>
											<option value="type3">pool type3</option>
											<option value="type4">pool type4</option>
										</select>
										<!-- <input type="file" class="form-control1" multiple="" name="images[]" id="inputPassword" placeholder="Password"> -->
									</div>
								</div>

								<!-- <div class="form-group">
									<label for="checkbox" class="col-sm-2 control-label">Category</label>
									<div class="col-sm-8">
										<div class="checkbox-inline1"><label><input type="checkbox" name="check1" value="Single Non AC"> Single Non AC</label></div> 
										<div class="checkbox-inline1"><label><input type="checkbox" name="check2" value="Double Non AC"> Double Non AC</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" name="check3" value="Single AC"> Single AC</label></div>
										<div class="checkbox-inline1"><label><input type="checkbox" name="check4" value="Double AC"> Double AC</label></div>
									</div>
								</div> -->
							<!-- 	<div class="form-group">
									<label for="checkbox" class="col-sm-2 control-label">Checkbox Inline</label>
									<div class="col-sm-8">
										<div class="checkbox-inline"><label><input type="checkbox"> Unchecked</label></div>
										<div class="checkbox-inline"><label><input type="checkbox" checked=""> Checked</label></div>
										<div class="checkbox-inline"><label><input type="checkbox" disabled=""> Disabled Unchecked</label></div>
										<div class="checkbox-inline"><label><input type="checkbox" disabled="" checked=""> Disabled Checked</label></div>
									</div>
								</div> -->
							<!-- 	<div class="form-group">
									<label for="selector1" class="col-sm-2 control-label">Dropdown Select</label>
									<div class="col-sm-8"><select name="selector1" id="selector1" class="form-control1">
										<option>Lorem ipsum dolor sit amet.</option>
										<option>Dolore, ab unde modi est!</option>
										<option>Illum, fuga minus sit eaque.</option>
										<option>Consequatur ducimus maiores voluptatum minima.</option>
									</select></div>
								</div> -->
							<!-- 	<div class="form-group">
									<label class="col-sm-2 control-label">Multiple Select</label>
									<div class="col-sm-8">
										<select multiple="" class="form-control1">
											<option>Option 1</option>
											<option>Option 2</option>
											<option>Option 3</option>
											<option>Option 4</option>
											<option>Option 5</option>
										</select>
									</div>
								</div> -->
							
						<!-- 		<div class="form-group">
									<label for="radio" class="col-sm-2 control-label">Radio</label>
									<div class="col-sm-8">
										<div class="radio block"><label><input type="radio"> Unchecked</label></div>
										<div class="radio block"><label><input type="radio" checked=""> Checked</label></div>
										<div class="radio block"><label><input type="radio" disabled=""> Disabled Unchecked</label></div>
										<div class="radio block"><label><input type="radio" disabled="" checked=""> Disabled Checked</label></div>
									</div>
								</div> -->
							<!-- 	<div class="form-group">
									<label for="radio" class="col-sm-2 control-label">Radio Inline</label>
									<div class="col-sm-8">
										<div class="radio-inline"><label><input type="radio"> Unchecked</label></div>
										<div class="radio-inline"><label><input type="radio" checked=""> Checked</label></div>
										<div class="radio-inline"><label><input type="radio" disabled=""> Disabled Unchecked</label></div>
										<div class="radio-inline"><label><input type="radio" disabled="" checked=""> Disabled Checked</label></div>
									</div>
								</div> -->


								<!-- <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Rate</h4><br>
								<div class="form-group">
									<label for="smallinput" class="col-sm-2 control-label label-input-sm">Single Non AC</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1 input-sm" id="smallinput" placeholder="Single Non AC Rate" name="rate1">
									</div>
								</div>
								<div class="form-group">
									<label for="mediuminput" class="col-sm-2 control-label">Double Non AC</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1" id="mediuminput" placeholder="Double Non AC Rate" name="rate2">
									</div>
								</div>
								<div class="form-group mb-n">
									<label for="largeinput" class="col-sm-2 control-label label-input-lg">Single Ac</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1 input-lg" id="largeinput" placeholder="Single Ac Rate" name="rate3">
									</div>
								</div>
									<div class="form-group mb-n">
									<label for="largeinput" class="col-sm-2 control-label label-input-lg">Double AC</label>
									<div class="col-sm-8">
										<input type="text" class="form-control1 input-lg" id="largeinput" placeholder="Double AC Rate" name="rate4">
									</div>
								</div> -->


									<div class="form-group">
									<label for="txtarea1"  class="col-sm-2 control-label">Description</label>
									<div class="col-sm-8"><textarea name="hotel_description" id="txtarea1" cols="50" rows="4" class="form-control1"  style="height: 80px;"><?php echo $value->hotel_description;?></textarea></div>
								</div>

					<div class="sub_home">
							<input type="submit" value="Submit" name="sub">
						<div class="clearfix"> </div>
					</div>
					
							</form>
						<?php } ?>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	
      <?php include('footer.php');?>