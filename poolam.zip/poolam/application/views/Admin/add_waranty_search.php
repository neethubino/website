<?php include('header.php')?>
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page signup-page">
				<?php 
				        $msg=$this->session->flashdata('msg');
				        if($msg)
				        {
				        ?>
				          
				        <div class="alert alert-success" >
				        <?php
				          echo $msg;
				        ?>
				        </div>
				        <?php 
				        }
				        ?>
				<!-- <h2 class="title1">REGISTER CUSTOMER HERE</h2> -->
				<div class="sign-up-row widget-shadow"  style="width: 100%;">
					<h5>Register Staff Here</h5>
					
				<form action="<?php echo base_url('Staff/staffregistercode');?>"
					method="post">
					
								<input type="text" placeholder="Staff Name" required="" name="name" pattern="^[a-zA-Z][\sa-zA-Z]*">

								<input type="text" placeholder="Contact Details" required="" name="phone"   pattern="[7-9]{1}[0-9]{9}" >

								<input type="email" placeholder="Email Id" required="" name="email">

								<input type="text" placeholder="Designation
								" required="" name="designation" pattern="^[a-zA-Z][\sa-zA-Z]*">

								<input type="email" placeholder="Username/ format(example@example.com)" class="
								" required="" name="username" pattern="^[a-zA-Z][\sa-zA-Z]*">

								<input type="text" placeholder="Password
								" required="" name="password" pattern="^[a-zA-Z][\sa-zA-Z]*">

								



				
					
					<div class="sub_home">
							<input type="submit" value="Submit">
						<div class="clearfix"> </div>
					</div>
					
				</form>
				</div>
			</div>
		</div>
		<!--footer-->
		<div class="footer">
		   <p>&copy; All Rights Reserved | Design by <a href="" target="_blank">intellize</a></p>
		</div>
        <!--//footer-->
	</div>
	
	<!-- side nav js -->
	<script src='<?php echo base_url();?>js/SidebarNav.min.js' type='text/javascript'></script>
	<script>
      $('.sidebar-menu').SidebarNav()
    </script>
	<!-- //side nav js -->
	
	<!-- Classie --><!-- for toggle left push menu script -->
		<script src="<?php echo base_url();?>js/classie.js"></script>
		<script>
			var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
				showLeftPush = document.getElementById( 'showLeftPush' ),
				body = document.body;
				
			showLeftPush.onclick = function() {
				classie.toggle( this, 'active' );
				classie.toggle( body, 'cbp-spmenu-push-toright' );
				classie.toggle( menuLeft, 'cbp-spmenu-open' );
				disableOther( 'showLeftPush' );
			};
			
			function disableOther( button ) {
				if( button !== 'showLeftPush' ) {
					classie.toggle( showLeftPush, 'disabled' );
				}
			}
		</script>
	<!-- //Classie --><!-- //for toggle left push menu script -->
	
	<!--scrolling js-->
	<script src="<?php echo base_url();?>js/jquery.nicescroll.js"></script>
	<script src="<?php echo base_url();?>js/scripts.js"></script>
	<!--//scrolling js-->
	
	<!-- Bootstrap Core JavaScript -->
	<script src="<?php echo base_url();?>js/bootstrap.js"> </script>
	
</body>
</html>