<?php include('header.php');?>

		<!-- main content start-->
		
		<div id="page-wrapper">
	
					
			<div class="main-page">
				<div class="tables">
					<h2 class="title1">Hotel Images</h2>


					<div class="bs-example widget-shadow" data-example-id="bordered-table"> 
					
						
						
				
						<h4>Hotel Images</h4>
						<?php 
						foreach ($details as $key => $value) {
					
						?>
						<form method="post" enctype="multipart/form-data" action="<?php echo base_url('Admin/addimage/'.$value->hotel_id);?>">
							<?php } ?>
						<div class="col-sm-8">
							<input type="file" name="image" class="form-control1" id="inputPassword" placeholder="Password">
						</div>
						<div class="sub_home">
							<input type="submit" value="Submit" name="sub">
						<div class="clearfix"> </div>
					</div>
					</form>

						<table class="table"> 
						<thead> 
							<tr> 
								
								<th>Hotel Image</th>
							    <th>Action</th>
							</tr>
						 </thead> 
						 <tbody> 
						 		<?php 
						foreach ($details as $key => $value) {
					
						?>
						 	<tr> 

						 		 <td><img  style="width: 200px; height: 150px;"  src="<?php echo base_url('upload/'.$value->images);?>"></td>
						 		  
						 		   
						 		      <td>
						 		      	  <a onclick="confirm('Are you sure')" href="<?php echo base_url('Admin/delroomimg/'.$value->room_id);?>"><i style="color: red;" class="fa fa-trash fa-2x" aria-hidden="true" ></i></a>
						 		      </td>  
						 		</tr>
						 	<?php } ?>
						   </tbody>
					    </table>
					
				</div>
					
					
				</div>
			</div>

		</div>
	<?php include('footer.php');?>