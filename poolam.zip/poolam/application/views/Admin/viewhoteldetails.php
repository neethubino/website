<?php include('header.php');?>

		<!-- main content start-->
		
		<div id="page-wrapper">
	
					
			<div class="main-page">
				<div class="tables">
					<h2 class="title1">Hotel Details</h2>


					<div class="bs-example widget-shadow" data-example-id="bordered-table"> 
					
						
						
				
						<h4>Hotel Details</h4>
						<table class="table table-bordered"> 
						<thead> 
							<tr> 
								<th>Hotel Name</th>
								<th>Location</th>
								<th>Hotel Image</th>
								<th>Description</th>
							  
							    <th>Category</th>
							  <th>Pool Type</th>
							    <!--  <th>INC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th> -->
							    <th>Action</th>
							<!--     <th>Action</th> -->
							</tr>
						 </thead> 
						 <tbody> 
						 		<?php 
						foreach ($details as $key => $value) {
					
						?>
						 	<tr> 

						 		<th scope="row"><?php echo $value->hotel_name;?></th>
						 		 <td><?php echo $value->location;?></td> 
						 		 <td><img  style="width: 200px; height: 150px;"  src="<?php echo base_url('upload/'.$value->hotel_image);?>"><br><a href="<?php echo base_url('Admin/viewimages/'.$value->hotel_id);?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;view more</a></td>
						 		  <td><p><?php echo $value->hotel_description;?></p></td>
						 		  <td><a href="<?php echo base_url('Admin/viewcategory/'.$value->hotel_id);?>">View Categories</a></td> 
						 		  <td><?php echo $value->pool_name;?></td>
						 		   
						 		      <td>
						 		      	 <a href="<?php echo base_url('Admin/update_hotel/'.$value->hotel_id);?>"> <i style="color: red;" class="fa fa-pencil-square-o fa-2x" aria-hidden="true"></i></a>
						 		      	  <a onclick="confirm('Are you sure')" href="<?php echo base_url('Admin/delhotel/'.$value->hotel_id);?>"><i style="color: red;" class="fa fa-trash fa-2x" aria-hidden="true" ></i></a>
						 		      </td>  
						 		</tr>
						 	<?php } ?>
						   </tbody>
					    </table>
					
				</div>
					
					
				</div>
			</div>

		</div>
	<?php include('footer.php');?>