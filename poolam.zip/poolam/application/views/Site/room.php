<?php include('header.php');?>
<section class="w3l-breadcrumb">
    <div class="breadcrum-bg py-sm-5 py-4">
        <div class="container py-lg-3">

            <h2>Hotels</h2>
            <p><a href="index.html">Home</a> &nbsp; / &nbsp; Hotels</p>

        </div>
    </div>
</section>
<div class="best-rooms w3l-blog py-5">
    <div class="container py-lg-5 py-sm-4">
        <div class="ban-content-inf row"> 




            <?php foreach ($details as $key => $value) {
                        
            ?>

            <div class="maghny-gd-1 col-lg-4 col-md-6">
                <div class="maghny-grid">
                    <figure class="effect-lily">
                        <img class="img-fluid"  style="height: 230px;" src="<?php echo base_url('upload/'.$value->hotel_image);?>">
                        <figcaption>
                            <div>
                                <h4 class="top-text" style="text-transform:uppercase;"><?php echo $value->hotel_name;?>
                                    <ul>
                                        <li> <span class="fa fa-star"></span></li>
                                        <li> <span class="fa fa-star"></span></li>
                                        <li> <span class="fa fa-star"></span></li>
                                        <li> <span class="fa fa-star"></span></li>
                                        <li> <span class="fa fa-star-o"></span></li>
                                    </ul>
                                </h4>
                                <p>Book for 20$ </p>
                            </div>
                        </figcaption>
                    </figure>
                    <div class="room-info" >
                       <!--  <h3 class="room-title"><a href="#url" style="color:#f57b51;"> <?php echo $value->hotel_name;?></a></h3> -->
                        <!-- <ul class="mb-3">
                            <li><span class="fa fa-users"></span> 2 Guests</li>
                            <li><span class="fa fa-bed"></span> 15sqft</li>
                        </ul> -->
                      <h5 style="color:#dc3545;"class="fa fa-map-marker">&nbsp;<?php echo $value->location;?></h5>
                        <p>Per Room/Per Night charges</p>
                        <hr style="   background: black">
                        
                         <p style="color: black;"> Category & Price:</p>
                            <div >
                         <label style="width:170px; ">   <input type="checkbox" name="A/c Single" value="A/c Single"> A/c Single</label>5000<br>
                           <label style="width:170px; ">   <input type="checkbox" name=""> Non Double A/c</label>6000 <br>
                          <label style="width:170px; ">    <input type="checkbox" name=""> Non Double A/c</label>7000<br>
                          <label style="width:170px; ">    <input type="checkbox" name=""> Non Double A/c
                           </label>8000
                        </div><!-- <div style="float: left; padding-left: 40px;">
                            <p>NA</p>
                              <p>5000</p><p>4000</p><p>5000</p>
                        </div> -->
                            <!-- <select name = "Alcatel" id="alcatel">
    <option disabled selected> ---Select---</option>
    <option value = "Alcatel-1230 + ZTE811"> A/c Single</option>
    <option value = "Alcatel-1231"> Non Double A/c </option>
    <option value = "Alcatel-351">A/c Single </option>
</select> -->
<!-- <div id="result" value="200"></div> -->




                        
                           <!--  <select>
                                  <option>  ---Select---</option>
                                <option>Non A/c Single</option>
                                  <option>Non Double A/c </option>
                                  <option> A/c Single</option>
                                  <option>A/c Double  </option>
                            </select> <b style="color: ;">$500</b> -->


                            <!-- <input type="checkbox"  name="category" value="true" > Non A/c Single </p> -->

                      <a href="<?php echo base_url('Home/booking');?>" class="btn mt-sm-4 mt-3">Book Now</a>
                        <div class="room-info-bottom" >
                            <ul class="room-amenities">
                                <li><a href="#url"><span class="fa fa-bed" title="Beds"></span></a></li>
                                <li><a href="#url"><span class="fa fa-television" title="Television"></span></a></li>
                                <li><a href="#url"><span class="fa fa-bath" title="Private Bathroom"></span></a></li>
                                <li><a href="#url"><span class="fa fa-motorcycle" title="Bike Rental"></span></a></li>
                            </ul>
                            <a href="<?php echo base_url('Home/room_single/'.$value->hotel_id);?>" class="btn view" style="color:#dc3545; ">Full Info →</a>
                        </div>
                    </div>
                </div><br>
            </div>

        <?php } ?>



          








        </div>
        <nav aria-label="Page navigation example">
            <ul class="pagination justify-content-center mt-5 mb-0">
                <li class="page-item disabled">
                    <a class="page-link page-prev" href="#previous" tabindex="-1">Previous</a>
                </li>
                <li class="page-item"><a class="page-link page-number" href="#1">1</a></li>
                <li class="page-item active"><a class="page-link page-number" href="#2">2</a></li>
                <li class="page-item"><a class="page-link page-number" href="#3">3</a></li>
                <li class="page-item"><a class="page-link page-next" href="#next">→</a></li>
            </ul>
        </nav>
    </div>
</div>

<script type="text/javascript">$(document).on("change", "#alcatel", function(){

    var alcatelval = $(this).val();
    
    if(alcatelval == 'Alcatel-1230 + ZTE811'){
        $("#result").text('USD 399');
    } else if(alcatelval == 'Alcatel-1231'){
        $("#result").text('USD 299');
    } else if(alcatelval == 'Alcatel-351'){
        $("#result").text('USD 169');
    }

})</script>
<?php include('footer.php');?>