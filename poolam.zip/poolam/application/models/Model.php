<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model extends CI_Model {

	public function __construct() 
	{
	    parent::__construct();
	    $this->load->helper('form');
	    $this->load->helper('url');
	    $this->load->database();
	    $this->load->model('model'); 
	    $this->load->library('session');  
	}  
	public function index()
	{
		$this->load->view('Site/index');
	}
	public function logincode1($table,$username,$password)
	{
		$this->db->select('*');
		$this->db->from($table);
		$this->db->where('username',$username); 
		$this->db->where('password',$password);
		if($data1=$this->db->get())
		{
			return $data1->row_array();
		}
		else
		{
			return false;
		}

	}
	function fetch_pass($session_id)
	{
	$fetch_pass=$this->db->query("select * from admin_login where id='$session_id'");
	$res=$fetch_pass->result();
	}
	function change_pass($session_id,$new_pass)
	{
	$update_pass=$this->db->query("UPDATE admin_login set password='$new_pass'  where id='$session_id'");
	}

	public function view($table)
	{
		$this->db->select('*');
		$this->db->from($table);
		$data=$this->db->get();
		return $data->result();
	}
	public function viewimages($table,$id)
	{
		$this->db->select('*');
		$this->db->from($table);
	    $this->db->where('hotel_id',$id);
		$data=$this->db->get();
		return $data->result();
	}
	public function viewcategory($table,$id)
	{
		$this->db->select('*');
		$this->db->from($table);
	    $this->db->where('hotel_id',$id);
		$data=$this->db->get();
		return $data->result();
	}
	public function delete($table,$id)
	{
		$this->db->where('hotel_id',$id);
		$this->db->delete($table);
	}
	public function deleteroom($table,$id)
	{
		$this->db->where('room_id',$id);
		$this->db->delete($table);
	}
	public function insert($table,$data)
	{
		$this->db->insert($table,$data);
	}
	public function update($table,$id)
	{
		$this->db->select('*');
		$this->db->from($table);
	    $this->db->where('hotel_id',$id);
		$data=$this->db->get();
		return $data->result();
	}
	public function updatehotel($table,$id,$data)
	{
		$this->db->where('hotel_id',$id);
		$this->db->update($table,$data);
	}

	





















	
	
	
	
	
	public function viewnextquestion($id)
	{
		// $select_query="select * FROM level1 WHERE q_no > '$id'  LIMIT 1;";
// 		$select_query="SELECT * FROM level1
// ORDER BY q_no and q_no > '$id' limit 1;";
		$select_query="SELECT * FROM level1 WHERE q_no = '$id' ORDER BY q_no ASC limit 1";
		$query=$this->db->query($select_query);
		return $query->result();
	
	}
	public function aselect($session_id)
	{
		$select_query="select status FROM `datas` where session_id= '$session_id' ORDER BY id DESC LIMIT 10";
			
		$query=$this->db->query($select_query);
		return $query->result();	
	}
	public function viewquestion($table)
	{
		$this->db->select('*');
		$this->db->from($table);
		$this->db->order_by('q_no','asc');
		$data=$this->db->get();
		return $data->result();
	}
	
	public function deletel($table,$id)
	{
		$this->db->where('level_id',$id);
		$this->db->delete($table);
	}
		
}