-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 23, 2020 at 02:24 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `poolam_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

DROP TABLE IF EXISTS `admin_login`;
CREATE TABLE IF NOT EXISTS `admin_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `username`, `password`) VALUES
(1, 'admin@admin.com', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) NOT NULL,
  `check1` varchar(50) DEFAULT NULL,
  `check2` varchar(50) DEFAULT NULL,
  `check3` varchar(50) DEFAULT NULL,
  `check4` varchar(50) DEFAULT NULL,
  `rate1` int(11) NOT NULL,
  `rate2` int(11) NOT NULL,
  `rate3` int(11) NOT NULL,
  `rate4` int(11) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `hotel_id`, `check1`, `check2`, `check3`, `check4`, `rate1`, `rate2`, `rate3`, `rate4`) VALUES
(16, 37, 'Single Non AC', NULL, 'Single AC', NULL, 5000, 0, 5000, 0),
(15, 36, 'Single Non AC', NULL, NULL, NULL, 5000, 0, 0, 0),
(14, 35, 'Single Non AC', NULL, 'Single AC', 'Double AC', 5000, 0, 5000, 622),
(13, 34, 'Single Non AC', NULL, NULL, NULL, 5000, 0, 0, 0),
(12, 33, 'Single Non AC', 'Double Non AC', NULL, NULL, 5000, 600, 0, 0),
(11, 32, 'Single Non AC', NULL, NULL, NULL, 5000, 0, 0, 0),
(10, 31, 'Single Non AC', NULL, NULL, NULL, 5000, 0, 0, 0),
(17, 38, 'Single Non AC', NULL, NULL, NULL, 800, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hotel_details`
--

DROP TABLE IF EXISTS `hotel_details`;
CREATE TABLE IF NOT EXISTS `hotel_details` (
  `hotel_id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_name` varchar(100) NOT NULL,
  `location` varchar(50) NOT NULL,
  `hotel_image` varchar(50) NOT NULL,
  `hotel_description` varchar(500) NOT NULL,
  `pool_name` varchar(50) NOT NULL,
  PRIMARY KEY (`hotel_id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hotel_details`
--

INSERT INTO `hotel_details` (`hotel_id`, `hotel_name`, `location`, `hotel_image`, `hotel_description`, `pool_name`) VALUES
(38, 'lulu', 'kochi', 'goat1.jpg', 'des', 'pool type3'),
(37, 'arcadia', 'kottayam', 'c2.jpg', '\r\n                            Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\n                            tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\n                            quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\n                            consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\n                            cillum dolore eu fugiat nulla pariatur. Excepteur sint occ', 'pool type2');

-- --------------------------------------------------------

--
-- Table structure for table `pool_type`
--

DROP TABLE IF EXISTS `pool_type`;
CREATE TABLE IF NOT EXISTS `pool_type` (
  `pool_id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) NOT NULL,
  `pool_name` varchar(50) NOT NULL,
  `pool_description` varchar(250) NOT NULL,
  PRIMARY KEY (`pool_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pool_type`
--

INSERT INTO `pool_type` (`pool_id`, `hotel_id`, `pool_name`, `pool_description`) VALUES
(2, 31, 'type1', ''),
(3, 32, 'type1', ''),
(4, 33, 'type3', ''),
(5, 34, 'type2', ''),
(6, 35, 'type2', ''),
(7, 36, 'type2', ''),
(8, 37, 'pool type2', ''),
(9, 38, 'pool type3', '');

-- --------------------------------------------------------

--
-- Table structure for table `room_images`
--

DROP TABLE IF EXISTS `room_images`;
CREATE TABLE IF NOT EXISTS `room_images` (
  `room_id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) NOT NULL,
  `images` varchar(50) NOT NULL,
  PRIMARY KEY (`room_id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_images`
--

INSERT INTO `room_images` (`room_id`, `hotel_id`, `images`) VALUES
(75, 38, 'lord-radha-krishna-on-swing-hd-wallpapers.jpg'),
(74, 38, 'images4.jpg'),
(73, 37, 'b33_-_Copy4.jpg'),
(72, 37, 'add_disease3.jpg'),
(71, 37, '6448472-wallpaper-hd-flowers7.jpg'),
(70, 37, '1233.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
